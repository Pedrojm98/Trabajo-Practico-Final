insert into usuarios (nombre, apellido, email, dni, direccion, telefono) values
('Ana', 'Pérez', 'ana.perez@gmail.com', '12345678', 'Av. Corrientes 1234', '123456789'),
('Luis', 'García', 'luis.garcia@gmail.com', '87654321', 'Av. Santa Fe 3456', '987654321'),
('María', 'López', 'maria.lopez@gmail.com', '23456789', 'Calle Rivadavia 789', '1122334455'),
('Jorge', 'Martínez', 'jorge.martinez@gmail.com', '34567890', 'Av. Belgrano 456', '2233445566'),
('Lucía', 'Ramírez', 'lucia.ramirez@gmail.com', '45678901', 'Calle Lavalle 1010', '3344556677'),
('Carlos', 'Sosa', 'carlos.sosa@gmail.com', '56789012', 'Av. Callao 234', '4455667788'),
('Laura', 'Fernández', 'laura.fernandez@gmail.com', '67890123', 'Calle Moreno 678', '5566778899'),
('Diego', 'Ruiz', 'diego.ruiz@gmail.com', '78901234', 'Av. Pueyrredón 890', '6677889900'),
('Marta', 'Silva', 'marta.silva@gmail.com', '89012345', 'Calle Perú 345', '7788990011'),
('Pedro', 'Iglesias', 'pedro.iglesias@gmail.com', '90123456', 'Av. Jujuy 567', '8899001122');

insert into categorias (nombre_categoria) values
('Ficción'),
('No Ficción'),
('Ciencia'),
('Historia'),
('Biografía');

insert into libros (titulo, autor, id_categoria, editorial, anio_de_edicion, disponible) values
('Cien Años de Soledad', 'Gabriel García Márquez', 1, 'Editorial Sudamericana', 1967, true),
('Breves respuestas a las grandes preguntas', 'Stephen Hawking', 3, 'Crítica', 2018, true),
('Sapiens', 'Yuval Noah Harari', 4, 'Debate', 2011, true),
('El Principito', 'Antoine de Saint-Exupéry', 1, 'Reynal & Hitchcock', 1943, true),
('Steve Jobs', 'Walter Isaacson', 5, 'Simon & Schuster', 2011, true),
('1984', 'George Orwell', 1, 'Secker & Warburg', 1949, true),
('Una breve historia del tiempo', 'Stephen Hawking', 3, 'Bantam Books', 1988, true),
('El universo en una cáscara de nuez', 'Stephen Hawking', 3, 'Debate', 2001, true),
('Los hombres me explican cosas', 'Rebecca Solnit', 2, 'Capitán Swing', 2014, true),
('El diario de Ana Frank', 'Ana Frank', 5, 'Contact Publishing', 1947, true);

insert into prestamos (id_usuario, id_libro, fecha_prestamo, fecha_devolucion, fecha_entrega_real) values
(1, 1, '2025-06-01', '2025-06-15', null),
(2, 2, '2025-06-05', '2025-06-20', '2025-06-19'),
(3, 5, '2025-06-10', '2025-06-25', null),
(4, 3, '2025-06-15', '2025-06-30', null),
(5, 6, '2025-06-20', '2025-07-05', null),
(2, 7, '2025-06-22', '2025-07-07', null),
(1, 9, '2025-06-25', '2025-07-10', null),
(6, 4, '2025-06-26', '2025-07-11', null),
(7, 8, '2025-06-27', '2025-07-12', null),
(8, 10, '2025-06-28', '2025-07-13', null);
