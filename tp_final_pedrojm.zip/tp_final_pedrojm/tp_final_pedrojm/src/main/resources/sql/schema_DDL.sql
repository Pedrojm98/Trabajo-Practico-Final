drop table if exists prestamos;
drop table if exists libros;
drop table if exists categorias;
drop table if exists usuarios;

create table usuarios (
    id_usuario int auto_increment,
    nombre varchar(50) not null,
    apellido varchar(50) not null,
    email varchar(100) null,
    dni char(8) not null,
    direccion varchar(100) null,
    telefono varchar(20) null,
    primary key (id_usuario)
);

create table categorias (
    id_categoria int auto_increment,
    nombre_categoria varchar(50) not null,
    primary key (id_categoria)
);

create table libros (
    id_libro int auto_increment,
    titulo varchar(100) not null,
    autor varchar(100) not null,
    id_categoria int not null,
    editorial varchar(100) null,
    anio_de_edicion year not null,
    disponible boolean not null,
    primary key (id_libro)
);

create table prestamos (
    id_prestamo int auto_increment,
    id_usuario int not null,
    id_libro int not null,
    fecha_prestamo date not null,
    fecha_devolucion date not null,
    fecha_entrega_real date null,
    primary key (id_prestamo)
);

alter table libros add constraint fk_libros_categorias
foreign key (id_categoria) references categorias(id_categoria);

alter table prestamos add constraint fk_prestamos_usuarios
foreign key (id_usuario) references usuarios(id_usuario);

alter table prestamos add constraint fk_prestamos_libros
foreign key (id_libro) references libros(id_libro);
