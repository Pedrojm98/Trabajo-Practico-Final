package ar.org.centro8.curso.java.repositories;

import ar.org.centro8.curso.java.entities.Categoria;
import ar.org.centro8.curso.java.repositories.interfaces.I_CategoriaRepository;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@Repository
public class CategoriaDAO implements I_CategoriaRepository {

    private final DataSource DATASOURCE;

    private static final String SQL_CREATE =
            "INSERT INTO categorias(nombre_categoria) VALUES (?)";
    private static final String SQL_FIND_BY_ID =
            "SELECT * FROM categorias WHERE id_categoria=?";
    private static final String SQL_FIND_ALL =
            "SELECT * FROM categorias";
    private static final String SQL_UPDATE =
            "UPDATE categorias SET nombre_categoria=? WHERE id_categoria=?";
    private static final String SQL_DELETE =
            "DELETE FROM categorias WHERE id_categoria=?";
    private static final String SQL_FIND_BY_NOMBRE =
            "SELECT * FROM categorias WHERE nombre_categoria LIKE ?";

    public CategoriaDAO(DataSource dataSource) {
        this.DATASOURCE = dataSource;
    }

    @Override
    public void create(Categoria categoria) throws SQLException {
        try (Connection conn = DATASOURCE.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_CREATE, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, categoria.getNombreCategoria());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    categoria.setIdCategoria(keys.getInt(1));
                }
            }
        }
    }

    @Override
    public Categoria findById(int id) throws SQLException {
        try (Connection conn = DATASOURCE.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        }
        return null;
    }

    @Override
    public List<Categoria> findAll() throws SQLException {
        List<Categoria> lista = new ArrayList<>();
        try (Connection conn = DATASOURCE.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_ALL);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(mapRow(rs));
            }
        }
        return lista;
    }

    @Override
    public int update(Categoria categoria) throws SQLException {
        try (Connection conn = DATASOURCE.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_UPDATE)) {
            ps.setString(1, categoria.getNombreCategoria());
            ps.setInt(2, categoria.getIdCategoria());
            return ps.executeUpdate();
        }
    }

    @Override
    public int delete(int id) throws SQLException {
        try (Connection conn = DATASOURCE.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_DELETE)) {
            ps.setInt(1, id);
            return ps.executeUpdate();
        }
    }

    @Override
    public List<Categoria> findByNombre(String nombre) throws SQLException {
        List<Categoria> lista = new ArrayList<>();
        try (Connection conn = DATASOURCE.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_NOMBRE)) {
            ps.setString(1, "%" + nombre + "%");
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapRow(rs));
                }
            }
        }
        return lista;
    }

    private Categoria mapRow(ResultSet rs) throws SQLException {
        return new Categoria(
                rs.getInt("id_categoria"),
                rs.getString("nombre_categoria")
        );
    }
}