package ar.org.centro8.curso.java.tests;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import ar.org.centro8.curso.java.entities.Usuario;
import ar.org.centro8.curso.java.entities.Libro;
import ar.org.centro8.curso.java.entities.Categoria;
import ar.org.centro8.curso.java.entities.Prestamo;

import ar.org.centro8.curso.java.repositories.UsuarioDAO;
import ar.org.centro8.curso.java.repositories.LibroDAO;
import ar.org.centro8.curso.java.repositories.CategoriaDAO;
import ar.org.centro8.curso.java.repositories.PrestamoDAO;

import ar.org.centro8.curso.java.repositories.interfaces.I_UsuarioRepository;
import ar.org.centro8.curso.java.repositories.interfaces.I_LibroRepository;
import ar.org.centro8.curso.java.repositories.interfaces.I_CategoriaRepository;
import ar.org.centro8.curso.java.repositories.interfaces.I_PrestamoRepository;
import java.util.List;

@SpringBootApplication(scanBasePackages = "ar.org.centro8.curso.java")

public class TestRepositories {
    public static void main(String[] args) {
        try (ConfigurableApplicationContext context = SpringApplication.run(TestRepositories.class, args)) {

            I_UsuarioRepository usuarioDAO = context.getBean(UsuarioDAO.class);
            I_LibroRepository libroDAO = context.getBean(LibroDAO.class);
            I_CategoriaRepository categoriaDAO = context.getBean(CategoriaDAO.class);
            I_PrestamoRepository prestamoDAO = context.getBean(PrestamoDAO.class);

            // Usuario
            List<Usuario> usuarios = usuarioDAO.findAll();
            if (!usuarios.isEmpty()) {
                System.out.println("Usuarios registrados: " + usuarios.size());
                usuarios.forEach(System.out::println);
            } else {
                System.out.println("No hay usuarios registrados.");
            }

            Usuario nuevoUsuario = new Usuario(0, "Carlos", "Mendoza", "carlos@mail.com", "12345678", "Calle Luna 123", "512345678");
            usuarioDAO.create(nuevoUsuario);
            if (nuevoUsuario.getIdUsuario() > 0) {
                System.out.println("Usuario creado: " + nuevoUsuario);

                nuevoUsuario.setTelefono("512345678");
                usuarioDAO.update(nuevoUsuario);
                Usuario actualizado = usuarioDAO.findById(nuevoUsuario.getIdUsuario());
                if (actualizado != null) {
                    System.out.println("Usuario actualizado: " + actualizado);
                } else {
                    System.err.println("¡¡ ERROR - No se pudo actualizar el usuario !!");
                }

                usuarioDAO.delete(nuevoUsuario.getIdUsuario());
                if (usuarioDAO.findById(nuevoUsuario.getIdUsuario()) == null) {
                    System.out.println("Usuario eliminado correctamente.");
                } else {
                    System.err.println("¡¡ ERROR - No se pudo eliminar el usuario !!");
                }
            } else {
                System.err.println("¡¡ ERROR - No se pudo crear el usuario !!");
            }

            // Libro
            List<Libro> libros = libroDAO.findAll();
            if (!libros.isEmpty()) {
                System.out.println("Libros registrados: " + libros.size());
                libros.forEach(System.out::println);
            } else {
                System.out.println("No hay libros registrados.");
            }

            Libro nuevoLibro = new Libro(0, "Nuevo Libro", "Autor Desconocido", 1, "Editorial X", 2025, true);
            libroDAO.create(nuevoLibro);
            if (nuevoLibro.getIdLibro() > 0) {
                System.out.println("Libro creado: " + nuevoLibro);

                nuevoLibro.setDisponible(false);
                libroDAO.update(nuevoLibro);
                Libro actualizado = libroDAO.findById(nuevoLibro.getIdLibro());
                if (actualizado != null) {
                    System.out.println("Libro actualizado: " + actualizado);
                } else {
                    System.err.println("¡¡ ERROR - No se pudo actualizar el libro !!");
                }

                libroDAO.delete(nuevoLibro.getIdLibro());
                if (libroDAO.findById(nuevoLibro.getIdLibro()) == null) {
                    System.out.println("Libro eliminado correctamente.");
                } else {
                    System.err.println("¡¡ ERROR - No se pudo eliminar el libro !!");
                }
            } else {
                System.err.println("¡¡ ERROR - No se pudo crear el libro !!");
            }

            // Categoría
            List<Categoria> categorias = categoriaDAO.findAll();
            if (!categorias.isEmpty()) {
                System.out.println("Categorías registradas: " + categorias.size());
                categorias.forEach(System.out::println);
            } else {
                System.out.println("No hay categorías registradas.");
            }

            // Préstamo
            List<Prestamo> prestamos = prestamoDAO.findAll();
            if (!prestamos.isEmpty()) {
                System.out.println("Préstamos registrados: " + prestamos.size());
                prestamos.forEach(System.out::println);
            } else {
                System.out.println("No hay préstamos registrados.");
            }

            Prestamo nuevoPrestamo = new Prestamo(0, 1, 1, java.time.LocalDate.now(), java.time.LocalDate.now().plusDays(7), null);
            prestamoDAO.create(nuevoPrestamo);
            if (nuevoPrestamo.getIdPrestamo() > 0) {
                System.out.println("Préstamo creado: " + nuevoPrestamo);

                nuevoPrestamo.setFechaEntregaReal(java.time.LocalDate.now().plusDays(5));
                prestamoDAO.update(nuevoPrestamo);
                Prestamo actualizado = prestamoDAO.findById(nuevoPrestamo.getIdPrestamo());
                if (actualizado != null) {
                    System.out.println("Préstamo actualizado: " + actualizado);
                } else {
                    System.err.println("¡¡ ERROR - No se pudo actualizar el préstamo !!");
                }

                prestamoDAO.delete(nuevoPrestamo.getIdPrestamo());
                if (prestamoDAO.findById(nuevoPrestamo.getIdPrestamo()) == null) {
                    System.out.println("Préstamo eliminado correctamente.");
                } else {
                    System.err.println("¡¡ ERROR - No se pudo eliminar el préstamo !!");
                }
            } else {
                System.err.println("¡¡ ERROR - No se pudo crear el préstamo !!");
            }

        } catch (Exception e) {
            System.out.println(" ¡¡ ERROR de la Base de Datos durante las pruebas !!");
            e.printStackTrace();
        } finally {
            System.out.println("<<< Pruebas finalizadas >>>.");
        }
    }
}