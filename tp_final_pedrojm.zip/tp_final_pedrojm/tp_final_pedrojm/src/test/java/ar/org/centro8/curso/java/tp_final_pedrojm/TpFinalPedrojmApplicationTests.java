package ar.org.centro8.curso.java.tp_final_pedrojm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TpFinalPedrojmApplicationTests {

	@Test
	void contextLoads() {
	}

}
