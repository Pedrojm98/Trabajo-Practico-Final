-- 1. mostrar todos los usuarios registrados
select * from usuarios;

-- 2. mostrar todos los libros disponibles
select * from libros
where  disponible = true;

-- 3. ver la lista de categorías de libros
select * from categorias;

-- 4. mostrar todos los préstamos realizados
select * from prestamos;

-- 5. ver quién pidió prestado un libro (nombre del usuario y título del libro)
select u.nombre, u.apellido, l.titulo
from   prestamos p
join   usuarios u on p.id_usuario = u.id_usuario
join   libros l on p.id_libro = l.id_libro;

-- 6. ver solo los libros que todavía no fueron devueltos
select l.titulo, u.nombre, u.apellido
from   prestamos p
join   libros l on p.id_libro = l.id_libro
join   usuarios u on p.id_usuario = u.id_usuario
where  p.fecha_entrega_real is null;

-- 7. Mostrar los libros más prestados
select   l.titulo, count(*) as veces_prestado
from     prestamos p
join     libros l on p.id_libro = l.id_libro
group by l.id_libro
order by veces_prestado desc
limit    5;

-- 8. Mostrar los usuarios que más libros han pedido prestados
select   u.nombre, u.apellido, COUNT(*) AS cantidad_prestamos
from     prestamos p
join     usuarios u on p.id_usuario = u.id_usuario
group by u.id_usuario
order by cantidad_prestamos desc;

-- 9. Mostrar libros por categoría
select   distinct c.nombre_categoria, l.titulo
from     libros l
join     categorias c on l.id_categoria = c.id_categoria
order by c.nombre_categoria;

-- 10. Mostrar préstamos vencidos (no devueltos y fecha límite pasada)
select   u.nombre, u.apellido, l.titulo, p.fecha_devolucion
from     prestamos p
join     usuarios u on p.id_usuario = u.id_usuario
join     libros l on p.id_libro = l.id_libro
where    p.fecha_entrega_real is null
and      p.fecha_devolucion < curdate();


