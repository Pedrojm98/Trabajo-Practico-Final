package ar.org.centro8.curso.java.controllers;

import ar.org.centro8.curso.java.models.entities.Libro;
import ar.org.centro8.curso.java.services.LibroService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.sql.SQLException;
import java.util.List;

@Controller
public class LibroController {

    private final LibroService libroService;

    public LibroController(LibroService libroService) {
        this.libroService = libroService;
    }

    @GetMapping("/libros")
    public String listarLibros(Model model) {
        try {
            List<Libro> libros = libroService.obtenerTodosLosLibros();
            model.addAttribute("libros", libros);
        } catch (SQLException e) {
            model.addAttribute("error", "Error al cargar los libros: " + e.getMessage());
            e.printStackTrace();
        }
        return "libro-lista";
    }

    @GetMapping("/libro/alta")
    public String altaLibroForm(Model model) {
        model.addAttribute("libro", new Libro());
        return "libro-alta";
    }

    @PostMapping("/libro/guardar")
    public String guardarLibro(@ModelAttribute("libro") Libro libro, Model model) {
        try {
            libroService.guardarLibro(libro);
            return "redirect:/libros";
        } catch (SQLException e) {
            model.addAttribute("error", "Error al guardar el libro: " + e.getMessage());
            return "libro-alta";
        } catch (IllegalArgumentException e) {
            model.addAttribute("error", e.getMessage());
            return "libro-alta";
        }
    }

    @GetMapping("/libro/eliminar")
    public String eliminarLibro(@RequestParam("id") int id, Model model) {
        try {
            libroService.eliminarLibro(id);
            return "redirect:/libros";
        } catch (SQLException e) {
            model.addAttribute("error", "Error al eliminar el libro: " + e.getMessage());
            return "libro-lista";
        }
    }

    @GetMapping("/libro/editar")
    public String editarLibroForm(@RequestParam("id") int id, Model model) {
        try {
            Libro libro = libroService.buscarLibroPorId(id);
            if (libro != null) {
                model.addAttribute("libro", libro);
                return "libro-editar";
            } else {
                return "redirect:/libros";
            }
        } catch (SQLException e) {
            model.addAttribute("error", "Error al cargar el libro para editar: " + e.getMessage());
            return "redirect:/libros";
        }
    }

    @PostMapping("/libro/actualizar")
    public String actualizarLibro(@ModelAttribute("libro") Libro libro, Model model) {
        try {
            libroService.guardarLibro(libro);
            return "redirect:/libros";
        } catch (SQLException e) {
            model.addAttribute("error", "Error al actualizar el libro: " + e.getMessage());
            return "libro-editar";
        } catch (IllegalArgumentException e) {
            model.addAttribute("error", e.getMessage());
            return "libro-editar";
        }
    }

    @GetMapping("/libros/buscarPorTitulo")
    public String buscarPorTitulo(@RequestParam(value = "titulo", required = false) String titulo, Model model) {
        try {
            List<Libro> libros;
            if (titulo != null && !titulo.isBlank()) {
                libros = libroService.buscarLibrosPorTitulo(titulo);
            } else {
                libros = libroService.obtenerTodosLosLibros();
            }
            model.addAttribute("libros", libros);
            model.addAttribute("titulo", titulo);
        } catch (SQLException e) {
            model.addAttribute("error", "Error al buscar libros: " + e.getMessage());
        }
        return "libro-lista";
    }
}