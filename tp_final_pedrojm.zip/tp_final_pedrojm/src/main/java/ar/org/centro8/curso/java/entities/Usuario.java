package ar.org.centro8.curso.java.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Usuario {
    
    private int idUsuario;
    private String nombre;
    private String apellido;
    private String email;
    private String dni;
    private String direccion;
    private String telefono;
}

