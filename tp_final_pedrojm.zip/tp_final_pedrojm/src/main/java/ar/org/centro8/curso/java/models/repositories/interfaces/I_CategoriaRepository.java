package ar.org.centro8.curso.java.models.repositories.interfaces;

import ar.org.centro8.curso.java.models.entities.Categoria;

import java.sql.SQLException;
import java.util.List;

public interface I_CategoriaRepository {
    void create(Categoria categoria) throws SQLException;
    Categoria findById(int id) throws SQLException;
    List<Categoria> findAll() throws SQLException;
    int update(Categoria categoria) throws SQLException;
    int delete(int id) throws SQLException;
    List<Categoria> findByNombre(String nombreCategoria) throws SQLException;
}
