package ar.org.centro8.curso.java.repositories.interfaces;

import java.sql.SQLException;
import java.util.List;

import ar.org.centro8.curso.java.entities.Prestamo;

public interface I_PrestamoRepository {
    void create(Prestamo prestamo) throws SQLException;
    Prestamo findById(int id) throws SQLException;
    List<Prestamo> findAll() throws SQLException;
    int update(Prestamo prestamo) throws SQLException;
    int delete(int id) throws SQLException;
    List<Prestamo> findByUsuario(int idUsuario) throws SQLException;
}
