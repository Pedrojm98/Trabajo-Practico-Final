package ar.org.centro8.curso.java.controllers;

import ar.org.centro8.curso.java.models.entities.Categoria;
import ar.org.centro8.curso.java.services.CategoriaService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.sql.SQLException;
import java.util.List;

@Controller
public class CategoriaController {

    private final CategoriaService categoriaService;

    public CategoriaController(CategoriaService categoriaService) {
        this.categoriaService = categoriaService;
    }

    @GetMapping("/categorias")
    public String listarCategorias(Model model) {
        try {
            List<Categoria> categorias = categoriaService.obtenerTodasLasCategorias();
            model.addAttribute("categorias", categorias);
        } catch (SQLException e) {
            model.addAttribute("error", "Error al cargar las categorías: " + e.getMessage());
            e.printStackTrace();
        }
        return "categoria-lista";
    }

    @GetMapping("/categoria/alta")
    public String altaCategoriaForm(Model model) {
        model.addAttribute("categoria", new Categoria());
        return "categoria-alta";
    }

    @PostMapping("/categoria/guardar")
    public String guardarCategoria(@ModelAttribute("categoria") Categoria categoria, Model model) {
        try {
            categoriaService.guardarCategoria(categoria);
            return "redirect:/categorias";
        } catch (SQLException e) {
            model.addAttribute("error", "Error al guardar la categoría: " + e.getMessage());
            return "categoria-alta";
        } catch (IllegalArgumentException e) {
            model.addAttribute("error", e.getMessage());
            return "categoria-alta";
        }
    }

    @GetMapping("/categoria/eliminar")
    public String eliminarCategoria(@RequestParam("id") int id, Model model) {
        try {
            categoriaService.eliminarCategoria(id);
            return "redirect:/categorias";
        } catch (SQLException e) {
            model.addAttribute("error", "Error al eliminar la categoría: " + e.getMessage());
            return "categoria-lista";
        }
    }

    @GetMapping("/categoria/editar")
    public String editarCategoriaForm(@RequestParam("id") int id, Model model) {
        try {
            Categoria categoria = categoriaService.buscarCategoriaPorId(id);
            if (categoria != null) {
                model.addAttribute("categoria", categoria);
                return "categoria-editar";
            } else {
                return "redirect:/categorias";
            }
        } catch (SQLException e) {
            model.addAttribute("error", "Error al cargar la categoría para editar: " + e.getMessage());
            return "redirect:/categorias";
        }
    }

    @PostMapping("/categoria/actualizar")
    public String actualizarCategoria(@ModelAttribute("categoria") Categoria categoria, Model model) {
        try {
            categoriaService.guardarCategoria(categoria);
            return "redirect:/categorias";
        } catch (SQLException e) {
            model.addAttribute("error", "Error al actualizar la categoría: " + e.getMessage());
            return "categoria-editar";
        } catch (IllegalArgumentException e) {
            model.addAttribute("error", e.getMessage());
            return "categoria-editar";
        }
    }

    @GetMapping("/categorias/buscarPorNombre")
    public String buscarPorNombre(@RequestParam(value = "nombre", required = false) String nombre, Model model) {
        try {
            List<Categoria> categorias;
            if (nombre != null && !nombre.isBlank()) {
                categorias = categoriaService.buscarCategoriasPorNombre(nombre);
            } else {
                categorias = categoriaService.obtenerTodasLasCategorias();
            }
            model.addAttribute("categorias", categorias);
            model.addAttribute("nombre", nombre);
        } catch (SQLException e) {
            model.addAttribute("error", "Error al buscar categorías: " + e.getMessage());
        }
        return "categoria-lista";
    }
}
