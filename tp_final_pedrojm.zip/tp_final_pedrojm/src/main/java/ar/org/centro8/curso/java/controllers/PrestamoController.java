package ar.org.centro8.curso.java.controllers;

import ar.org.centro8.curso.java.models.entities.Prestamo;
import ar.org.centro8.curso.java.services.PrestamoService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.sql.SQLException;
import java.util.List;

@Controller
public class PrestamoController {

    private final PrestamoService prestamoService;

    public PrestamoController(PrestamoService prestamoService) {
        this.prestamoService = prestamoService;
    }

    @GetMapping("/prestamos")
    public String listarPrestamos(Model model) {
        try {
            List<Prestamo> prestamos = prestamoService.obtenerTodosLosPrestamos();
            model.addAttribute("prestamos", prestamos);
        } catch (SQLException e) {
            model.addAttribute("error", "Error al cargar los préstamos: " + e.getMessage());
            e.printStackTrace();
        }
        return "prestamo-lista";
    }

    @GetMapping("/prestamo/alta")
    public String altaPrestamoForm(Model model) {
        model.addAttribute("prestamo", new Prestamo());
        return "prestamo-alta";
    }

    @PostMapping("/prestamo/guardar")
    public String guardarPrestamo(@ModelAttribute("prestamo") Prestamo prestamo, Model model) {
        try {
            prestamoService.guardarPrestamo(prestamo);
            return "redirect:/prestamos";
        } catch (SQLException e) {
            model.addAttribute("error", "Error al guardar el préstamo: " + e.getMessage());
            return "prestamo-alta";
        } catch (IllegalArgumentException e) {
            model.addAttribute("error", e.getMessage());
            return "prestamo-alta";
        }
    }

    @GetMapping("/prestamo/eliminar")
    public String eliminarPrestamo(@RequestParam("id") int id, Model model) {
        try {
            prestamoService.eliminarPrestamo(id);
            return "redirect:/prestamos";
        } catch (SQLException e) {
            model.addAttribute("error", "Error al eliminar el préstamo: " + e.getMessage());
            return "prestamo-lista";
        }
    }

    @GetMapping("/prestamo/editar")
    public String editarPrestamoForm(@RequestParam("id") int id, Model model) {
        try {
            Prestamo prestamo = prestamoService.buscarPrestamoPorId(id);
            if (prestamo != null) {
                model.addAttribute("prestamo", prestamo);
                return "prestamo-editar";
            } else {
                return "redirect:/prestamos";
            }
        } catch (SQLException e) {
            model.addAttribute("error", "Error al cargar el préstamo para editar: " + e.getMessage());
            return "redirect:/prestamos";
        }
    }

    @PostMapping("/prestamo/actualizar")
    public String actualizarPrestamo(@ModelAttribute("prestamo") Prestamo prestamo, Model model) {
        try {
            prestamoService.guardarPrestamo(prestamo);
            return "redirect:/prestamos";
        } catch (SQLException e) {
            model.addAttribute("error", "Error al actualizar el préstamo: " + e.getMessage());
            return "prestamo-editar";
        } catch (IllegalArgumentException e) {
            model.addAttribute("error", e.getMessage());
            return "prestamo-editar";
        }
    }

    @GetMapping("/prestamos/buscarPorUsuario")
    public String buscarPorUsuario(@RequestParam("idUsuario") int idUsuario, Model model) {
        try {
            List<Prestamo> prestamos = prestamoService.buscarPrestamosPorUsuario(idUsuario);
            model.addAttribute("prestamos", prestamos);
            model.addAttribute("idUsuario", idUsuario);
        } catch (SQLException e) {
            model.addAttribute("error", "Error al buscar préstamos del usuario: " + e.getMessage());
        }
        return "prestamo-lista";
    }
}
