package ar.org.centro8.curso.java.services;

import ar.org.centro8.curso.java.models.entities.Libro;
import ar.org.centro8.curso.java.models.repositories.interfaces.I_LibroRepository;
import org.springframework.stereotype.Service;

import java.sql.SQLException;
import java.util.List;

@Service
public class LibroService {

    private final I_LibroRepository libroRepository;

    public LibroService(I_LibroRepository libroRepository) {
        this.libroRepository = libroRepository;
    }

    public List<Libro> obtenerTodosLosLibros() throws SQLException {
        return libroRepository.findAll();
    }

    public Libro guardarLibro(Libro libro) throws SQLException {
        validarLibro(libro);

        if (libro.getIdLibro() != 0) {
            libroRepository.update(libro);
        } else {
            libroRepository.create(libro);
        }
        return libro;
    }

    public Libro buscarLibroPorId(int id) throws SQLException {
        return libroRepository.findById(id);
    }

    public int eliminarLibro(int id) throws SQLException {
        return libroRepository.delete(id);
    }

    public List<Libro> buscarLibrosPorTitulo(String titulo) throws SQLException {
        return libroRepository.findByTitulo(titulo);
    }

    private void validarLibro(Libro libro) {
        if (libro.getTitulo() == null || libro.getTitulo().isBlank()) {
            throw new IllegalArgumentException("El título del libro no puede estar vacío.");
        }
        if (libro.getAutor() == null || libro.getAutor().isBlank()) {
            throw new IllegalArgumentException("El autor del libro no puede estar vacío.");
        }
        if (libro.getAnioDeEdicion() < 1000 || libro.getAnioDeEdicion() > 2100) {
            throw new IllegalArgumentException("El año de edición debe ser válido.");
        }
    }
}
