package ar.org.centro8.curso.java.models.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Libro {
    private int idLibro;
    private String titulo;
    private String autor;
    private int idCategoria;
    private String editorial;
    private int anioDeEdicion;
    private boolean disponible;

}
