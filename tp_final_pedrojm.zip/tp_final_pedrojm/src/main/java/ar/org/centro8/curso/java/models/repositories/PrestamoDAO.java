package ar.org.centro8.curso.java.models.repositories;


import ar.org.centro8.curso.java.models.entities.Prestamo;
import ar.org.centro8.curso.java.models.repositories.interfaces.I_PrestamoRepository;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Repository
public class PrestamoDAO implements I_PrestamoRepository {

    private final DataSource DATASOURCE;

    private static final String SQL_CREATE =
            "INSERT INTO prestamos(id_usuario, id_libro, fecha_prestamo, fecha_devolucion, fecha_entrega_real) VALUES (?,?,?,?,?)";
    private static final String SQL_FIND_BY_ID =
            "SELECT * FROM prestamos WHERE id_prestamo=?";
    private static final String SQL_FIND_ALL =
            "SELECT * FROM prestamos";
    private static final String SQL_UPDATE =
            "UPDATE prestamos SET id_usuario=?, id_libro=?, fecha_prestamo=?, fecha_devolucion=?, fecha_entrega_real=? WHERE id_prestamo=?";
    private static final String SQL_DELETE =
            "DELETE FROM prestamos WHERE id_prestamo=?";
    private static final String SQL_FIND_BY_USUARIO =
            "SELECT * FROM prestamos WHERE id_usuario=?";

    public PrestamoDAO(DataSource dataSource) {
        this.DATASOURCE = dataSource;
    }

    @Override
    public void create(Prestamo prestamo) throws SQLException {
        try (Connection conn = DATASOURCE.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_CREATE, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, prestamo.getIdUsuario());
            ps.setInt(2, prestamo.getIdLibro());
            ps.setDate(3, Date.valueOf(prestamo.getFechaPrestamo()));
            ps.setDate(4, Date.valueOf(prestamo.getFechaDevolucion()));
            if (prestamo.getFechaEntregaReal() != null) {
                ps.setDate(5, Date.valueOf(prestamo.getFechaEntregaReal()));
            } else {
                ps.setNull(5, Types.DATE);
            }
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    prestamo.setIdPrestamo(keys.getInt(1));
                }
            }
        }
    }

    @Override
    public Prestamo findById(int id) throws SQLException {
        try (Connection conn = DATASOURCE.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        }
        return null;
    }

    @Override
    public List<Prestamo> findAll() throws SQLException {
        List<Prestamo> lista = new ArrayList<>();
        try (Connection conn = DATASOURCE.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_ALL);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(mapRow(rs));
            }
        }
        return lista;
    }

    @Override
    public int update(Prestamo prestamo) throws SQLException {
        try (Connection conn = DATASOURCE.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_UPDATE)) {
            ps.setInt(1, prestamo.getIdUsuario());
            ps.setInt(2, prestamo.getIdLibro());
            ps.setDate(3, Date.valueOf(prestamo.getFechaPrestamo()));
            ps.setDate(4, Date.valueOf(prestamo.getFechaDevolucion()));
            if (prestamo.getFechaEntregaReal() != null) {
                ps.setDate(5, Date.valueOf(prestamo.getFechaEntregaReal()));
            } else {
                ps.setNull(5, Types.DATE);
            }
            ps.setInt(6, prestamo.getIdPrestamo());
            return ps.executeUpdate();
        }
    }

    @Override
    public int delete(int id) throws SQLException {
        try (Connection conn = DATASOURCE.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_DELETE)) {
            ps.setInt(1, id);
            return ps.executeUpdate();
        }
    }

    @Override
    public List<Prestamo> findByUsuario(int idUsuario) throws SQLException {
        List<Prestamo> lista = new ArrayList<>();
        try (Connection conn = DATASOURCE.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_USUARIO)) {
            ps.setInt(1, idUsuario);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapRow(rs));
                }
            }
        }
        return lista;
    }

    private Prestamo mapRow(ResultSet rs) throws SQLException {
        LocalDate fechaEntregaReal = null;
        Date entregaReal = rs.getDate("fecha_entrega_real");
        if (entregaReal != null) fechaEntregaReal = entregaReal.toLocalDate();

        return new Prestamo(
                rs.getInt("id_prestamo"),
                rs.getInt("id_usuario"),
                rs.getInt("id_libro"),
                rs.getDate("fecha_prestamo").toLocalDate(),
                rs.getDate("fecha_devolucion").toLocalDate(),
                fechaEntregaReal
        );
    }
}