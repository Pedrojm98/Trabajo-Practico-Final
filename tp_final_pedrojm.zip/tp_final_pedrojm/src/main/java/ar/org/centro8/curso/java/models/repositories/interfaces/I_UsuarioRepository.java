package ar.org.centro8.curso.java.models.repositories.interfaces;

import java.sql.SQLException;
import java.util.List;
import ar.org.centro8.curso.java.models.entities.Usuario;

public interface I_UsuarioRepository {
    void create(Usuario usuario) throws SQLException;
    Usuario findById(int id) throws SQLException;
    List<Usuario> findAll() throws SQLException;
    int update(Usuario usuario) throws SQLException;
    int delete(int id) throws SQLException;
    List<Usuario> findByDni(String dni) throws SQLException;
}