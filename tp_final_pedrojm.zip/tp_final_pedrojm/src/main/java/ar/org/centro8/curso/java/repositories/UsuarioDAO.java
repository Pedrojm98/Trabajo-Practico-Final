package ar.org.centro8.curso.java.repositories;

import ar.org.centro8.curso.java.entities.Usuario;
import ar.org.centro8.curso.java.repositories.interfaces.I_UsuarioRepository;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@Repository
public class UsuarioDAO implements I_UsuarioRepository {

    private final DataSource DATASOURCE;

    private static final String SQL_CREATE =
            "INSERT INTO usuarios(nombre, apellido, email, dni, direccion, telefono) VALUES (?,?,?,?,?,?)";
    private static final String SQL_FIND_BY_ID =
            "SELECT * FROM usuarios WHERE id_usuario=?";
    private static final String SQL_FIND_ALL =
            "SELECT * FROM usuarios";
    private static final String SQL_UPDATE =
            "UPDATE usuarios SET nombre=?, apellido=?, email=?, dni=?, direccion=?, telefono=? WHERE id_usuario=?";
    private static final String SQL_DELETE =
            "DELETE FROM usuarios WHERE id_usuario=?";
    private static final String SQL_FIND_BY_DNI =
            "SELECT * FROM usuarios WHERE dni=?";

    public UsuarioDAO(DataSource dataSource) {
        this.DATASOURCE = dataSource;
    }

    @Override
    public void create(Usuario usuario) throws SQLException {
        try (Connection conn = DATASOURCE.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_CREATE, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, usuario.getNombre());
            ps.setString(2, usuario.getApellido());
            ps.setString(3, usuario.getEmail());
            ps.setString(4, usuario.getDni());
            ps.setString(5, usuario.getDireccion());
            ps.setString(6, usuario.getTelefono());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    usuario.setIdUsuario(keys.getInt(1));
                }
            }
        }
    }

    @Override
    public Usuario findById(int id) throws SQLException {
        try (Connection conn = DATASOURCE.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        }
        return null;
    }

    @Override
    public List<Usuario> findAll() throws SQLException {
        List<Usuario> lista = new ArrayList<>();
        try (Connection conn = DATASOURCE.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_ALL);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(mapRow(rs));
            }
        }
        return lista;
    }

    @Override
    public int update(Usuario usuario) throws SQLException {
        try (Connection conn = DATASOURCE.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_UPDATE)) {
            ps.setString(1, usuario.getNombre());
            ps.setString(2, usuario.getApellido());
            ps.setString(3, usuario.getEmail());
            ps.setString(4, usuario.getDni());
            ps.setString(5, usuario.getDireccion());
            ps.setString(6, usuario.getTelefono());
            ps.setInt(7, usuario.getIdUsuario());
            return ps.executeUpdate();
        }
    }

    @Override
    public int delete(int id) throws SQLException {
        try (Connection conn = DATASOURCE.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_DELETE)) {
            ps.setInt(1, id);
            return ps.executeUpdate();
        }
    }

    @Override
    public List<Usuario> findByDni(String dni) throws SQLException {
        List<Usuario> lista = new ArrayList<>();
        try (Connection conn = DATASOURCE.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_DNI)) {
            ps.setString(1, dni);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapRow(rs));
                }
            }
        }
        return lista;
    }

    private Usuario mapRow(ResultSet rs) throws SQLException {
        return new Usuario(
                rs.getInt("id_usuario"),
                rs.getString("nombre"),
                rs.getString("apellido"),
                rs.getString("email"),
                rs.getString("dni"),
                rs.getString("direccion"),
                rs.getString("telefono")
        );
    }
}