package ar.org.centro8.curso.java.services;

import ar.org.centro8.curso.java.models.entities.Categoria;
import ar.org.centro8.curso.java.models.repositories.interfaces.I_CategoriaRepository;
import org.springframework.stereotype.Service;

import java.sql.SQLException;
import java.util.List;

@Service
public class CategoriaService {

    private final I_CategoriaRepository categoriaRepository;

    public CategoriaService(I_CategoriaRepository categoriaRepository) {
        this.categoriaRepository = categoriaRepository;
    }

    public List<Categoria> obtenerTodasLasCategorias() throws SQLException {
        return categoriaRepository.findAll();
    }

    public Categoria guardarCategoria(Categoria categoria) throws SQLException {
        validarCategoria(categoria);

        if (categoria.getIdCategoria() != 0) {
            categoriaRepository.update(categoria);
        } else {
            categoriaRepository.create(categoria);
        }
        return categoria;
    }

    public Categoria buscarCategoriaPorId(int id) throws SQLException {
        return categoriaRepository.findById(id);
    }

    public int eliminarCategoria(int id) throws SQLException {
        return categoriaRepository.delete(id);
    }

    public List<Categoria> buscarCategoriasPorNombre(String nombre) throws SQLException {
        return categoriaRepository.findByNombre(nombre);
    }

    private void validarCategoria(Categoria categoria) {
        if (categoria.getNombreCategoria() == null || categoria.getNombreCategoria().isBlank()) {
            throw new IllegalArgumentException("El nombre de la categoría no puede estar vacío.");
        }
    }
}
