package ar.org.centro8.curso.java.tp_final_pedrojm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TpFinalPedrojmApplication {

	public static void main(String[] args) {
		SpringApplication.run(TpFinalPedrojmApplication.class, args);
	}

}
