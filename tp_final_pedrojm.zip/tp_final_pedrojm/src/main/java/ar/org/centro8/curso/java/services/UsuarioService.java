package ar.org.centro8.curso.java.services;

import ar.org.centro8.curso.java.models.entities.Usuario;
import ar.org.centro8.curso.java.models.repositories.interfaces.I_UsuarioRepository;
import org.springframework.stereotype.Service;

import java.sql.SQLException;
import java.util.List;

@Service
public class UsuarioService {

    private final I_UsuarioRepository usuarioRepository;

    public UsuarioService(I_UsuarioRepository usuarioRepository) {
        this.usuarioRepository = usuarioRepository;
    }

    public List<Usuario> obtenerTodosLosUsuarios() throws SQLException {
        return usuarioRepository.findAll();
    }

    public Usuario guardarUsuario(Usuario usuario) throws SQLException {
        validarUsuario(usuario);
        if (usuario.getIdUsuario() != 0) {
            usuarioRepository.update(usuario);
        } else {
            usuarioRepository.create(usuario);
        }
        return usuario;
    }

    public Usuario buscarUsuarioPorId(int id) throws SQLException {
        return usuarioRepository.findById(id);
    }

    public int eliminarUsuario(int id) throws SQLException {
        return usuarioRepository.delete(id);
    }

    public List<Usuario> buscarUsuariosPorDni(String dni) throws SQLException {
        return usuarioRepository.findByDni(dni);
    }

    private void validarUsuario(Usuario usuario) {
        if (usuario.getNombre() == null || usuario.getNombre().isBlank()) {
            throw new IllegalArgumentException("El nombre no puede estar vacío.");
        }
        if (usuario.getApellido() == null || usuario.getApellido().isBlank()) {
            throw new IllegalArgumentException("El apellido no puede estar vacío.");
        }
        if (usuario.getDni() == null || usuario.getDni().length() < 7) {
            throw new IllegalArgumentException("El DNI debe tener al menos 7 caracteres.");
        }
        if (usuario.getEmail() == null || !usuario.getEmail().contains("@")) {
            throw new IllegalArgumentException("El email no es válido.");
        }
    }
}