package ar.org.centro8.curso.java.services;

import ar.org.centro8.curso.java.models.entities.Prestamo;
import ar.org.centro8.curso.java.models.repositories.interfaces.I_PrestamoRepository;
import org.springframework.stereotype.Service;

import java.sql.SQLException;
import java.util.List;

@Service
public class PrestamoService {

    private final I_PrestamoRepository prestamoRepository;

    public PrestamoService(I_PrestamoRepository prestamoRepository) {
        this.prestamoRepository = prestamoRepository;
    }

    public List<Prestamo> obtenerTodosLosPrestamos() throws SQLException {
        return prestamoRepository.findAll();
    }

    public Prestamo guardarPrestamo(Prestamo prestamo) throws SQLException {
        validarPrestamo(prestamo);

        if (prestamo.getIdPrestamo() != 0) {
            prestamoRepository.update(prestamo);
        } else {
            prestamoRepository.create(prestamo);
        }
        return prestamo;
    }

    public Prestamo buscarPrestamoPorId(int id) throws SQLException {
        return prestamoRepository.findById(id);
    }

    public int eliminarPrestamo(int id) throws SQLException {
        return prestamoRepository.delete(id);
    }

    public List<Prestamo> buscarPrestamosPorUsuario(int idUsuario) throws SQLException {
        return prestamoRepository.findByUsuario(idUsuario);
    }

    private void validarPrestamo(Prestamo prestamo) {
        if (prestamo.getIdUsuario() <= 0) {
            throw new IllegalArgumentException("El ID de usuario no es válido.");
        }
        if (prestamo.getIdLibro() <= 0) {
            throw new IllegalArgumentException("El ID del libro no es válido.");
        }
        if (prestamo.getFechaPrestamo() == null) {
            throw new IllegalArgumentException("La fecha de préstamo es obligatoria.");
        }
    }
}
