package ar.org.centro8.curso.java.controllers;

import ar.org.centro8.curso.java.models.entities.Usuario;
import ar.org.centro8.curso.java.services.UsuarioService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.sql.SQLException;
import java.util.List;

@Controller
public class UsuarioController {

    private final UsuarioService usuarioService;

    public UsuarioController(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

    @GetMapping("/usuarios")
    public String listarUsuarios(Model model) {
        try {
            List<Usuario> usuarios = usuarioService.obtenerTodosLosUsuarios();
            model.addAttribute("usuarios", usuarios);
        } catch (SQLException e) {
            e.printStackTrace();
            model.addAttribute("error", "Error al cargar los usuarios: " + e.getMessage());
        }
        return "usuario-lista";
    }

    @GetMapping("/usuario/alta")
    public String altaUsuarioForm(Model model) {
        model.addAttribute("usuario", new Usuario());
        return "usuario-alta";
    }

    @PostMapping("/usuario/guardar")
    public String guardarUsuario(@ModelAttribute("usuario") Usuario usuario, Model model) {
        try {
            usuarioService.guardarUsuario(usuario);
            return "redirect:/usuarios";
        } catch (SQLException e) {
            e.printStackTrace();
            model.addAttribute("error", "Error al guardar el usuario: " + e.getMessage());
            return "usuario-alta";
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
            model.addAttribute("error", e.getMessage());
            return "usuario-alta";
        }
    }

    @GetMapping("/usuario/eliminar")
    public String eliminarUsuario(@RequestParam("id") int id, Model model) {
        try {
            usuarioService.eliminarUsuario(id);
            return "redirect:/usuarios";
        } catch (SQLException e) {
            e.printStackTrace();
            model.addAttribute("error", "Error al eliminar el usuario: " + e.getMessage());
            return "usuario-lista";
        }
    }

    @GetMapping("/usuario/editar")
    public String editarUsuarioForm(@RequestParam("id") int id, Model model) {
        try {
            Usuario usuario = usuarioService.buscarUsuarioPorId(id);
            if (usuario != null) {
                model.addAttribute("usuario", usuario);
                return "usuario-editar";
            } else {
                return "redirect:/usuarios";
            }
        } catch (SQLException e) {
            e.printStackTrace();
            model.addAttribute("error", "Error al cargar el usuario para editar: " + e.getMessage());
            return "redirect:/usuarios";
        }
    }

    @PostMapping("/usuario/actualizar")
    public String actualizarUsuario(@ModelAttribute("usuario") Usuario usuario, Model model) {
        try {
            usuarioService.guardarUsuario(usuario);
            return "redirect:/usuarios";
        } catch (SQLException e) {
            e.printStackTrace();
            model.addAttribute("error", "Error al actualizar el usuario: " + e.getMessage());
            return "usuario-editar";
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
            model.addAttribute("error", e.getMessage());
            return "usuario-editar";
        }
    }

    @GetMapping("/usuarios/buscarPorDni")
    public String buscarUsuariosPorDni(@RequestParam(value = "dni", required = false) String dni, Model model) {
        try {
            List<Usuario> usuarios;
            if (dni != null && !dni.isBlank()) {
                usuarios = usuarioService.buscarUsuariosPorDni(dni);
            } else {
                usuarios = usuarioService.obtenerTodosLosUsuarios();
            }
            model.addAttribute("usuarios", usuarios);
            model.addAttribute("dni", dni);
        } catch (SQLException e) {
            e.printStackTrace();
            model.addAttribute("error", "Error al buscar usuarios: " + e.getMessage());
        }
        return "usuario-lista";
    }
}
