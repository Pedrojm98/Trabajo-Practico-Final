package ar.org.centro8.curso.java.repositories;

import ar.org.centro8.curso.java.entities.Libro;
import ar.org.centro8.curso.java.repositories.interfaces.I_LibroRepository;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@Repository
public class LibroDAO implements I_LibroRepository {

    private final DataSource DATASOURCE;

    private static final String SQL_CREATE =
            "INSERT INTO libros(titulo, autor, id_categoria, editorial, anio_de_edicion, disponible) VALUES (?,?,?,?,?,?)";
    private static final String SQL_FIND_BY_ID =
            "SELECT * FROM libros WHERE id_libro=?";
    private static final String SQL_FIND_ALL =
            "SELECT * FROM libros";
    private static final String SQL_UPDATE =
            "UPDATE libros SET titulo=?, autor=?, id_categoria=?, editorial=?, anio_de_edicion=?, disponible=? WHERE id_libro=?";
    private static final String SQL_DELETE =
            "DELETE FROM libros WHERE id_libro=?";
    private static final String SQL_FIND_BY_TITULO =
            "SELECT * FROM libros WHERE titulo LIKE ?";

    public LibroDAO(DataSource dataSource) {
        this.DATASOURCE = dataSource;
    }

    @Override
    public void create(Libro libro) throws SQLException {
        try (Connection conn = DATASOURCE.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_CREATE, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, libro.getTitulo());
            ps.setString(2, libro.getAutor());
            ps.setInt(3, libro.getIdCategoria());
            ps.setString(4, libro.getEditorial());
            ps.setInt(5, libro.getAnioDeEdicion());
            ps.setBoolean(6, libro.isDisponible());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    libro.setIdLibro(keys.getInt(1));
                }
            }
        }
    }

    @Override
    public Libro findById(int id) throws SQLException {
        try (Connection conn = DATASOURCE.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        }
        return null;
    }

    @Override
    public List<Libro> findAll() throws SQLException {
        List<Libro> lista = new ArrayList<>();
        try (Connection conn = DATASOURCE.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_ALL);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(mapRow(rs));
            }
        }
        return lista;
    }

    @Override
    public int update(Libro libro) throws SQLException {
        try (Connection conn = DATASOURCE.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_UPDATE)) {
            ps.setString(1, libro.getTitulo());
            ps.setString(2, libro.getAutor());
            ps.setInt(3, libro.getIdCategoria());
            ps.setString(4, libro.getEditorial());
            ps.setInt(5, libro.getAnioDeEdicion());
            ps.setBoolean(6, libro.isDisponible());
            ps.setInt(7, libro.getIdLibro());
            return ps.executeUpdate();
        }
    }

    @Override
    public int delete(int id) throws SQLException {
        try (Connection conn = DATASOURCE.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_DELETE)) {
            ps.setInt(1, id);
            return ps.executeUpdate();
        }
    }

    @Override
    public List<Libro> findByTitulo(String titulo) throws SQLException {
        List<Libro> lista = new ArrayList<>();
        try (Connection conn = DATASOURCE.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_TITULO)) {
            ps.setString(1, "%" + titulo + "%");
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapRow(rs));
                }
            }
        }
        return lista;
    }

    private Libro mapRow(ResultSet rs) throws SQLException {
        return new Libro(
                rs.getInt("id_libro"),
                rs.getString("titulo"),
                rs.getString("autor"),
                rs.getInt("id_categoria"),
                rs.getString("editorial"),
                rs.getInt("anio_de_edicion"),
                rs.getBoolean("disponible")
        );
    }
}